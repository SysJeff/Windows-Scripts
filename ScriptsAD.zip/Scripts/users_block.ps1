Import-Module ActiveDirectory
$lockedOutUsersCount = (Search-ADAccount -LockedOut -UsersOnly | Measure-Object).Count
Write-Output "Número de usuários bloqueados: $lockedOutUsersCount"