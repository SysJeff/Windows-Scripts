Import-Module ActiveDirectory
repadmin /showrepl /homeserver:SEU SERVIDOR

