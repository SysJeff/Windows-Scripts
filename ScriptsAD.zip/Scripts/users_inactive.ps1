Import-Module ActiveDirectory
(Get-ADUser -Filter 'Enabled -eq $False').Count 
