Import-Module ActiveDirectory
$cutoffDate = (Get-Date).AddDays(-60)
Get-ADUser -Filter {LastLogonDate -lt $cutoffDate -and Enabled -eq $true} -Properties LastLogonDate | Select Name, LastLogonDate

