Import-Module ActiveDirectory
repadmin /showrepl /homeserver:CVH-BDC.cvh.local 

