Import-Module ActiveDirectory
(Get-ADUser -Filter 'Enabled -eq $True').Count